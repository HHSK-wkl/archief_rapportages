# source("R/CODE_index_setup.R")

# LETOP overal de beoordeling vervangen voor het juiste jaar

## ---- prep-krw ----

# INFORMATIE OVER WATERLICHAAM TOVOEGEN AAN POPUP

waterlichamen <- st_read("data/waterlichamen.gpkg", quiet = TRUE)

f_krw_omsch <-
  tibble::tribble(
  ~code,                                ~omsch,
  "M10",         "Laagveen vaarten en kanalen",
  "M14",    "Grote ondiepe gebufferde plassen",
  "M1a",             "Zoete gebufferde sloten",
  "M20",  "Matig grote diepe gebufferde meren",
  "M27", "Matig grote ondiepe laagveenplassen",
   "M3",      "Gebufferde (regionale) kanalen",
  "M30",                 "Zwak brakke wateren",
   "M8",           "Gebufferde laagveensloten"
  ) %>% maak_opzoeker()

krw_data <-
  readxl::read_excel("data/waterlichamen_ekrs_en_doelen_2022.xlsx") %>%
  mutate(type = fct_relevel(type, c("Algen", "Waterplanten", "Macrofauna", "Vis")),
         groep = fct_relevel(groep, "Boezem", "Plassen", "Sloten", "Kanalen Krimpenerwaard", "Kanalen Schieland")) %>%
  mutate(OWMNAAM = ifelse(OWMNAAM == "Eendragtspolder_roeibaan", "Eendragtspolder roeibaan", OWMNAAM ))


# Waterlichamen-kaart -------------------------------------------------------------------

# popup_data <- krw_data %>%
#   select(OWMIDENT, OWMNAAM, Watertype) %>%
#   distinct() %>%
#   mutate(popup_tekst = glue("<b>Waterlichaam:</b> {OWMNAAM}<br><b>Watertype:</b> {f_krw_omsch(Watertype)} ({Watertype})")) %>%
#   select(OWMIDENT, popup_tekst)

popup_data <-
  krw_data %>%
  # mutate(oordeel = cut(ekr_2021 / doelen, c(0, 0.33333, 0.66666, 1, 50), labels = c("Slecht", "Ontoereikend", "Matig", "Goed"))) %>%
  mutate(frac = ekr_2022 / doelen,
         oordeel = scales::percent(ifelse(frac > 1, 1, frac), accuracy = 1)) %>%
  group_by(OWMIDENT, OWMNAAM, Watertype) %>%
  summarise(oordeel = glue_collapse(glue("<b>{type}:</b> {oordeel}", .na = "-"), sep = "<br>")) %>%
  ungroup() %>%
  mutate(popup_tekst = glue("<b>Waterlichaam:</b> {OWMNAAM}<br><b>Watertype:</b> {f_krw_omsch(Watertype)} ({Watertype})<hr><b>Toestand t.o.v. doel</b><br>{oordeel}")) %>%
  select(OWMIDENT, popup_tekst)

pal <- leaflet::colorFactor(palette = RColorBrewer::brewer.pal(9, "Set1") , domain = waterlichamen$OWMNAAM)

kaart_waterlichamen <-
  waterlichamen %>%
  left_join(popup_data, by = "OWMIDENT") %>%
  # mutate(popup_tekst = OWMNAAM) %>%
  st_transform(crs = 4326) %>%
  leaflet() %>%
  leaflet::addProviderTiles(leaflet::providers$CartoDB.Positron, group = "Kaart") %>%
  leaflet::addProviderTiles(leaflet::providers$Esri.WorldImagery, group = "Luchtfoto") %>%
  leaflet::addLayersControl(baseGroups = c("Kaart", "Luchtfoto"),
                            options = leaflet::layersControlOptions(collapsed = FALSE), position = "topleft") %>%
  addPolylines(data = ws_grens, opacity = 1, color = "grey", weight = 2, label = "waterschapsgrens") %>%
  addPolygons(weight = 4, color = ~pal(OWMNAAM),
              fillOpacity = 0.8, opacity = 0.8,
              label = ~OWMNAAM,
              popup = ~popup_tekst,
              highlightOptions = highlightOptions(color = blauw, bringToFront = TRUE, opacity = 1))


# KRW-doelen -----------------------------------------------------------------

krw_doelen <-
  krw_data %>%
  mutate(fractie = doelen / 0.6,
         fractie = if_else(fractie > 1, 1, fractie)) %>%
  mutate(doelaanpassing = 1 - fractie) %>%
  rename(doel = fractie) %>%
  pivot_longer(cols = c(doel, doelaanpassing), names_to = "dummy", values_to = "fractie2") %>%

  ggplot(aes(fractie2, fct_reorder(OWMNAAM, OWMIDENT, .fun = first, .desc = TRUE), fill = fct_rev(dummy))) +
  geom_col() +
  facet_grid(cols = vars(type), rows = vars(groep),
             scales = "free_y", space = "free_y", switch = "y", labeller = label_wrap_gen(16)) +
  scale_fill_manual(values = c(doel = blauw_m, doelaanpassing = grijs_m)) +
  scale_x_continuous(limits = c(0, 1), expand = c(0, 0),
                     labels = function(x) scales::percent(x, accuracy = 1), breaks = pretty_breaks(2)) +
  labs(x = "Hoogte doel t.o.v. standaard",
       y ="",
       title = "Doelen waterlichamen",
       caption = "Sloten zijn watergangen die smaller zijn dan 8 meter, kanalen zijn watergangen die breder zijn dan 8 meter.") +
  hhskthema() +
  theme(panel.spacing = unit(1.5, "lines"),
        plot.margin = margin(5.5, 15, 5.5, 5.5, unit = "pt"),
        strip.placement = "outside",
        axis.ticks.y = element_blank(),
        axis.line.y = element_blank(),
        panel.grid.major.y =  element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "top",
        plot.title.position = "plot") +
  guides(fill = guide_legend(title = "", reverse = TRUE))


# KRW-opgave --------------------------------------------------------------

krw_opgave <-
  krw_data %>%
  mutate(fractie = ekr_2022 / doelen,
         fractie = if_else(fractie > 1, 1, fractie)) %>%
  mutate(doelgat = 1 - fractie) %>%
  rename(`huidige toestand` = fractie) %>%
  pivot_longer(cols = c(`huidige toestand`, doelgat), names_to = "dummy", values_to = "fractie2") %>%
  ggplot(aes(fractie2, fct_reorder(OWMNAAM, OWMIDENT, .fun = first, .desc = TRUE), fill = dummy)) +
  geom_col() +
  facet_grid(cols = vars(type), rows = vars(groep),
             scales = "free_y", space = "free_y", switch = "y", labeller = label_wrap_gen(16)) +
  scale_fill_manual(values = c("huidige toestand" = blauw_m, doelgat = oranje_m)) +
  scale_x_continuous(limits = c(0, 1), expand = c(0, 0),
                     labels = function(x) scales::percent(x, accuracy = 1), breaks = pretty_breaks(2)) +
  labs(x = "Toestand ten opzichte van het doel",
       y ="",
       title = "Opgave waterlichamen",
       caption = "Sloten zijn watergangen die smaller zijn dan 8 meter, kanalen zijn watergangen die breder zijn dan 8 meter.") +
  hhskthema() +
  theme(panel.spacing = unit(1.5, "lines"),
        plot.margin = margin(5.5, 15, 5.5, 5.5, unit = "pt"),
        strip.placement = "outside",
        axis.ticks.y = element_blank(),
        axis.line.y = element_blank(),
        panel.grid.major.y =  element_blank(),
        panel.grid.major.x = element_blank(),
        legend.position = "top",
        plot.title.position = "plot") +
  guides(fill = guide_legend(title = "", reverse = TRUE))


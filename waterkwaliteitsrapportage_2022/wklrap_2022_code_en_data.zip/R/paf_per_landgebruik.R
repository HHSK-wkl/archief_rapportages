paf <-
  fys_chem %>%
  filter(parnr > 999, parnr < 2000,
         # year(datum) >= begin_10_jaar
         ) %>%
  add_jaar() %>%
  # group_by(mp, jaar, parnr) %>%
  # filter(n() > 1) %>% # verwijder alle meetjaren van locaties waar in 1 jaar een par maar 1 keer is gemeten
  # ungroup() %>%
  # group_by(mp, jaar) %>%
  # filter(n_distinct(parnr) > 50) %>% # verwijder alle locaties waar zeer beperkt is gemeten
  # ungroup() %>%
  # group_by(jaar) %>%
  # filter(n_distinct(mp, datum) > 20) %>% # verwijder jaren met minder dan 20 monsters
  # ungroup() %>%
  # gbm_10 %>%
  mutate(paf_acuut = paf_gbm(f_aquopar(parnr),
                             concentratie = waarde,
                             detectiegrens = detectiegrens,
                             ssd_data = toxiciteit,
                             type_paf = "acuut"),
         paf_chronisch = paf_gbm(f_aquopar(parnr),
                                 concentratie = waarde,
                                 detectiegrens = detectiegrens,
                                 ssd_data = toxiciteit,
                                 type_paf = "chronisch")) %>%
  # afhandelen detectiegrenswaarden
  mutate(paf_acuut = ifelse(is.na(detectiegrens) | is.na(paf_acuut), paf_acuut, 0),
         paf_chronisch = ifelse(is.na(detectiegrens) | is.na(paf_chronisch), paf_chronisch, 0))

mspaf_monsters <- paf %>%
  group_by(mp, jaar, datum) %>%
  summarise(`Acute effecten` = mspaf(paf_acuut),
            `Chronische effecten` = mspaf(paf_chronisch)) %>%
  ungroup() %>%
  mutate(mp2 = glue("{f_landgebruik(mp)} -- {mp}")) %>%
  mutate(mp2 = fct_reorder(mp2, `Acute effecten`))


paf %>%
  filter(is.na(detectiegrens), jaar == 2022) %>%
  group_by(par, parnr) %>%
  summarise(tox_niet_beschikbaar = sum(is.na(paf_acuut)) != 0) %>%
  ungroup() %>%
  pull(tox_niet_beschikbaar) %>%
  sum()


paf %>%
  filter(jaar > 2008) %>%
  group_by(mp, jaar, parnr, par) %>%
  summarise(paf_acuut = max(paf_acuut, na.rm = TRUE),
            paf_chronisch = max(paf_chronisch, na.rm = TRUE)) %>%
  ungroup() %>%
  mutate(paf_acuut = ifelse(paf_acuut < 0, 0, paf_acuut),
         paf_chronisch = ifelse(paf_chronisch < 0, 0, paf_chronisch)) %>%
  group_by(mp, jaar) %>%
  summarise(mspaf_acuut = mspaf(paf_acuut),
            mspaf_chronisch = mspaf(paf_chronisch)) %>%
  ungroup() %>%
  mutate(landgebruik = f_landgebruik(mp)) %>%
  group_by(landgebruik, jaar) %>%
  summarise(mspaf_acuut_gem = mean(mspaf_acuut),
            mspaf_chronisch_gem = mean(mspaf_chronisch)) %>%

  group_by(landgebruik) %>%
  filter(n()> 3) %>%
  ungroup() %>%
  mutate(landgebruik =fct_reorder(landgebruik, mspaf_acuut_gem, .desc = TRUE)) %>%
  ggplot(aes(jaar, mspaf_chronisch_gem)) +
  geom_line(colour = blauw) + geom_point(colour = blauw) +
  facet_wrap(~landgebruik) +
  scale_y_continuous(limits = c(0, NA), expand = expansion(c(0, 0.1)))


paf %>%
  filter(is.na(detectiegrens), jaar == 2022) %>%
  select(parnr, par) %>% distinct() %>% View()

paf %>%
  filter(jaar > 2008) %>%
  group_by(mp, jaar, datum) %>%
  summarise(mspaf_acuut = mspaf(paf_acuut),
            mspaf_chronisch = mspaf(paf_chronisch)) %>%
  ungroup() %>%
  mutate(landgebruik = f_landgebruik(mp)) %>%
  group_by(landgebruik, jaar) %>%
  summarise(mspaf_acuut_gem = mean(mspaf_acuut),
            mspaf_chronisch_gem = mean(mspaf_chronisch)) %>%

  group_by(landgebruik) %>%
  filter(n()> 3) %>%
  ungroup() %>%
  mutate(landgebruik =fct_reorder(landgebruik, mspaf_acuut_gem, .desc = TRUE)) %>%
  ggplot(aes(jaar, mspaf_acuut_gem)) +
  geom_smooth(se = FALSE, alpha = 0.5, colour = "grey", linetype = "dashed", method = "lm") +
  geom_line(colour = blauw) + geom_point(colour = blauw)  +
  facet_wrap(~landgebruik) +
  scale_y_continuous(limits = c(0, NA), expand = expansion(c(0, 0.1)))

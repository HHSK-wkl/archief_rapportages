overig_water <- st_read("data/gebiedsindeling_overig_water.gpkg", quiet = TRUE)

waterlichamen <- st_read("data/waterlichamen.gpkg", quiet = TRUE)

wl <- waterlichamen %>% summarise(n())

f_krw_omsch <-
  tibble::tribble(
    ~code,                                ~omsch,
    "M10",         "Laagveen vaarten en kanalen",
    "M14",    "Grote ondiepe gebufferde plassen",
    "M1a",             "Zoete gebufferde sloten",
    "M20",  "Matig grote diepe gebufferde meren",
    "M27", "Matig grote ondiepe laagveenplassen",
    "M3",      "Gebufferde (regionale) kanalen",
    "M30",                 "Zwak brakke wateren",
    "M8",           "Gebufferde laagveensloten"
  ) %>% maak_opzoeker()

# krw_data <-
#   readxl::read_excel("data/waterlichamen_ekrs_en_doelen_2021.xlsx") %>%
#   mutate(type = fct_relevel(type, c("Algen", "Waterplanten", "Macrofauna", "Vis")),
#          groep = fct_relevel(groep, "Boezem", "Plassen", "Sloten", "Kanalen Krimpenerwaard", "Kanalen Schieland")) %>%
#   mutate(OWMNAAM = ifelse(OWMNAAM == "Eendragtspolder_roeibaan", "Eendragtspolder roeibaan", OWMNAAM ))


# Waterlichamen-kaart -------------------------------------------------------------------

# popup_data <-
#   krw_data %>%
#   # mutate(oordeel = cut(ekr_2021 / doelen, c(0, 0.33333, 0.66666, 1, 50), labels = c("Slecht", "Ontoereikend", "Matig", "Goed"))) %>%
#   mutate(frac = ekr_2021 / doelen,
#          oordeel = scales::percent(ifelse(frac > 1, 1, frac), accuracy = 1)) %>%
#   group_by(OWMIDENT, OWMNAAM, Watertype) %>%
#   summarise(oordeel = glue_collapse(glue("<b>{type}:</b> {oordeel}", .na = "-"), sep = "<br>")) %>%
#   ungroup() %>%
#   mutate(popup_tekst = glue("<b>Waterlichaam:</b> {OWMNAAM}<br><b>Watertype:</b> {f_krw_omsch(Watertype)} ({Watertype})<hr><b>Toestand t.o.v. doel</b><br>{oordeel}")) %>%
#   select(OWMIDENT, popup_tekst)

pal <- leaflet::colorFactor(palette = RColorBrewer::brewer.pal(9, "Set1") , domain = overig_water$naam_ovw)

kaart_overig_water <-
  overig_water %>%
  group_by(naam_ovw) %>%
  summarise(n()) %>%
  ungroup() %>%
  filter(!is.na(naam_ovw)) %>%
  st_buffer(dist = 1) %>%
  # left_join(popup_data, by = "OWMIDENT") %>%
  # mutate(popup_tekst = OWMNAAM) %>%
  st_transform(crs = 4326) %>%
  leaflet() %>%
  leaflet::addProviderTiles(leaflet::providers$CartoDB.Positron, group = "Kaart") %>%
  leaflet::addProviderTiles(leaflet::providers$Esri.WorldImagery, group = "Luchtfoto") %>%
  leaflet::addLayersControl(baseGroups = c("Kaart", "Luchtfoto"),
                            options = leaflet::layersControlOptions(collapsed = FALSE), position = "topleft") %>%
  addPolylines(data = ws_grens, opacity = 1, color = "grey", weight = 2, label = "waterschapsgrens") %>%
  addPolygons(weight = 4, color = ~pal(naam_ovw),
              fillOpacity = 0.6, opacity = 0.8,
              label = ~naam_ovw,
              # popup = ~popup_tekst,
              highlightOptions = highlightOptions(color = blauw, bringToFront = TRUE, opacity = 1))

kaart_overig_water

a <- waterlichamen %>%
  filter(OWMIDENT %in% c("NL39_11a", "NL39_12a", "NL39_27","NL39_28","NL39_29")) %>%
  st_buffer(dist = 80)

b <- waterlichamen %>%
  filter(OWMIDENT %in% c("NL39_05a", "NL39_24a", "NL39_26a", "NL39_07a", "NL39_04a")) %>%
  st_buffer(dist = 50)

c <- waterlichamen %>%
  filter(!OWMIDENT %in% c("NL39_11a", "NL39_12a", "NL39_27","NL39_28","NL39_29", "NL39_05a", "NL39_24a", "NL39_26a", "NL39_07a", "NL39_04a")) %>%
  st_buffer(dist = 20)


wl2 <- bind_rows(a,b,c) %>% summarise(n())

x <-
  overig_water %>%
  group_by(naam_ovw) %>%
  summarise(n()) %>%
  ungroup() %>%
  filter(!is.na(naam_ovw)) %>%
  st_difference(wl2)

st_write(x, "data/overig_water_kaart.gpkg")

st_read("data/overig_water_kaart.gpkg") %>%
  ggplot() +
  # ggspatial::annotation_map_tile(type = "cartolight", zoomin = 0) +
  geom_sf(aes(fill = naam_ovw), colour = NA, alpha = 0.5) +
  hhskthema_kaart() +
  theme(legend.position = "bottom") +
  scale_fill_manual(values = c(Akkerbouwgebied       = RColorBrewer::brewer.pal(12, "Set1")[6], # akkerbouw
                               Glastuinbouwgebied    = RColorBrewer::brewer.pal(12, "Set1")[2],
                               Weidegebied            = RColorBrewer::brewer.pal(12, "Set3")[7],
                               "Stedelijk gebied"       = RColorBrewer::brewer.pal(12, "Set1")[1],
                               "Eendragtspolder plas-dras"= RColorBrewer::brewer.pal(12, "Set1")[5],
                               "Zwemplas Krimpenerhout"= RColorBrewer::brewer.pal(12, "Set1")[4],
                               "Natuurgebied"= RColorBrewer::brewer.pal(12, "Set1")[3],
                               "Waterparel Zuidplaspolder"= RColorBrewer::brewer.pal(12, "Set1")[8]))





overig_water %>%
  ggplot() + geom_sf()

f_kleur_ov <- function(naam_ovw){
  vec <- c(Akkerbouwgebied       = RColorBrewer::brewer.pal(12, "Set1")[6], # akkerbouw
           Glastuinbouwgebied    = RColorBrewer::brewer.pal(12, "Set1")[2],
           Weidegebied            = RColorBrewer::brewer.pal(12, "Set3")[7],
           "Stedelijk gebied"       = RColorBrewer::brewer.pal(12, "Set1")[1],
           "Eendragtspolder plas-dras"= RColorBrewer::brewer.pal(12, "Set1")[5],
           "Zwemplas Krimpenerhout"= RColorBrewer::brewer.pal(12, "Set1")[4],
           "Natuurgebied"= RColorBrewer::brewer.pal(12, "Set1")[3],
           "Waterparel Zuidplaspolder"= RColorBrewer::brewer.pal(12, "Set1")[8])
  unname(vec[naam_ovw])
}

st_read("data/overig_water_kaart.gpkg") %>%
  st_transform(crs = 4326) %>%
  basiskaart() %>%
  addPolylines(data = ws_grens, opacity = 1, color = "grey", weight = 2, label = "waterschapsgrens") %>%
  addPolygons(color = ~f_kleur_ov(naam_ovw), fillOpacity = 0.8, stroke = 0, label = ~naam_ovw, popup = ~naam_ovw)

  # addPolygons(weight = 4, color = ~pal(OWMNAAM),
  #             fillOpacity = 0.8, opacity = 0.8,
  #             label = ~OWMNAAM,
  #             popup = ~popup_tekst,
  #             highlightOptions = highlightOptions(color = blauw, bringToFront = TRUE, opacity = 1))
  #


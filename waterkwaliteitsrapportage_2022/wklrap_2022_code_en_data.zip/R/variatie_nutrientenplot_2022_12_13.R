datp <-
  grafiek_data %>%
  filter(parnr == 3) %>%
  mutate(kleur = kleuren_functies_nutrienten[as.character(landgebruik)]) %>%
  mutate(kleur = darken(kleur))

kleuren <- kleuren_functies_nutrienten %>% darken(amount = 0.3, space = "combined", method = "absolute") %>% set_names(str_to_lower(names(kleuren_functies_nutrienten)))

# p1 <-
  datp %>%

  mutate(landgebruik = fct_reorder(landgebruik, waarde_gem, .desc = TRUE)) %>%
  ggplot(aes(jaar, waarde_gem, group = landgebruik, colour = landgebruik)) +
  geom_line(linewidth = 1) +
  # geom_smooth(se = FALSE, span = 0.8) +
  # scale_color_brewer(palette = "Dark2", guide = FALSE) +
  scale_colour_manual(values = kleuren, guide = FALSE) +
  scale_y_continuous(limits = c(0,NA), expand = expansion(c(0,0.1))) +
  scale_x_continuous(breaks = pretty_breaks(n = 10), limits = c(NA, NA)) +
  labs(title = "Gemiddelde fosfaatconcentratie",
       x = "",
       y = "mg P/l"
       )  +
  coord_cartesian(clip = "off") +
  theme(plot.margin = margin(5.5, 120, 5.5, 5.5, unit = "pt")) +
  ggrepel::geom_text_repel(aes(label = landgebruik, x = jaar+0.1), data = filter(datp, jaar == rap_jaar),
             hjust = "left",  size = 5, direction = "y", nudge_x = 0.2, xlim = c(NA, rap_jaar + 3)) +
  NULL

datn <- grafiek_data %>%
  filter(parnr == 7) %>%
  mutate(kleur = kleuren_functies_nutrienten[as.character(landgebruik)])

# p2 <-
  datn %>%
  mutate(landgebruik = fct_reorder(landgebruik, waarde_gem, .desc = TRUE)) %>%
  ggplot(aes(jaar, waarde_gem, group = landgebruik, colour = landgebruik)) +
  geom_line(linewidth = 1) +
  # geom_smooth(se = FALSE, span = 0.8) +
  # scale_color_brewer(palette = "Dark2", guide = FALSE) +
  scale_colour_manual(values = kleuren, guide = FALSE) +
  scale_y_continuous(limits = c(0,NA), expand = expansion(c(0,0.1))) +
  scale_x_continuous(breaks = pretty_breaks(n = 10), limits = c(NA, NA)) +
  labs(title = "Gemiddelde Stikstofconcentratie",
       x = "",
       y = "mg N/l"
  )  +
  coord_cartesian(clip = "off") +
  theme(plot.margin = margin(5.5, 120, 5.5, 5.5, unit = "pt")) +
  ggrepel::geom_text_repel(aes(label = landgebruik, x = jaar+0.1), data = filter(datn, jaar == rap_jaar),
                           hjust = "left",  size = 5, direction = "y", nudge_x = 0.2, xlim = c(NA, rap_jaar + 3)) +
  NULL


p1 | p2

p1 / p2


  thema_line_facet +
  scale_color_identity() +
  # scale_fill_manual(values = c(hhskblauw, "grey60"), labels = c(rap_jaar, "Andere jaren"), ) +
  theme(legend.position = "none",
        panel.spacing = unit(25, "points"),
        axis.ticks.x = element_blank(),
        strip.text = element_markdown())

library(ggforce)

p1 +
  facet_zoom(ylim = c(0,5))



# # Fys-chem gebied -------------------------------------------------------

fys_chem %>%
  add_jaar_maand() %>%
  filter(parnr == 7, jaar >= rap_jaar - 9) %>%
  group_by(mp, jaar, maand) %>%
  summarise(waarde = mean(waarde)) %>%
  group_by(mp, jaar) %>%
  summarise(waarde = mean(waarde)) %>%
  mutate(gebied = f_gebied(mp)) %>%
  mutate(landgebruik = f_landgebruik(mp)) %>%
  filter(landgebruik %in% landgebruik_sel) %>%
  # group_by(jaar, gebied) %>%
  # summarise(waarde = mean(waarde)) %>%
  filter(gebied %in% c("Schieland", "Krimpenerwaard")) %>%
  ungroup() %>%
  mutate(landgebruik = fct_reorder(landgebruik, waarde, .desc = TRUE, .fun = mean)) %>%
  ggplot(aes(jaar, waarde, colour = landgebruik), shape = 20) +
  ggbeeswarm::geom_quasirandom(width = 0.3) +
  # geom_point(aes(group = mp), alpha = 0.2) +
  geom_smooth(se = FALSE, span = 0.8) +
  scale_y_continuous(limits = c(0, 35), expand = expansion(c(0, 0.1))) +
  scale_x_continuous(limits = c(rap_jaar - 9, rap_jaar), breaks = pretty_breaks(10)) +
  scale_color_discrete(guide = FALSE) +
  facet_wrap(~landgebruik, scales = "free", ncol = 2) +
  NULL


fys_chem %>%
  add_jaar_maand() %>%
  filter(parnr == 3, jaar >= rap_jaar - 12.5) %>%
  group_by(mp, jaar, maand) %>%
  summarise(waarde = mean(waarde)) %>%
  group_by(mp, jaar) %>%
  summarise(waarde = mean(waarde)) %>%
  mutate(gebied = f_gebied(mp)) %>%
  filter(gebied %in% c("Schieland", "Krimpenerwaard")) %>%
  mutate(landgebruik = f_landgebruik(mp)) %>%
  filter(landgebruik %in% landgebruik_sel) %>%
  mutate(jaar2 = cut(jaar, c(0, rap_jaar-12.5, rap_jaar-9.5,rap_jaar-2.5, rap_jaar),
                     labels = c("1", "2012", "2", "2022"))) %>%
  group_by(jaar2, landgebruik) %>%
  summarise(waarde = mean(waarde)) %>%
  filter(jaar2 != "2", jaar2 != "1") %>%
  ungroup() %>%
  mutate(jaar2 = as.numeric(as.character(jaar2))) %>%
  # mutate(landgebruik = fct_reorder(landgebruik, waarde, .desc = TRUE, .fun = mean)) %>%
  ggplot(aes(jaar2, waarde, colour = landgebruik), shape = 20) +
  geom_point() + geom_line() +
  scale_y_continuous(limits = c(0, NA), expand = expansion(c(0, 0.1)))

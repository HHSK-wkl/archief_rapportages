dat <-
  grafiek_data %>%
  filter(parnr == 3) %>%
  mutate(landgebruik = fct_reorder(landgebruik, waarde_gem, .desc = TRUE)) %>%
  arrange(landgebruik, jaar) %>%
  mutate(tijd = as.double(row_number()))

fosfor_plot <-
  dat %>%
  ggplot(aes(jaar, waarde_gem, group = landgebruik, colour = landgebruik)) +
  geom_line(linewidth = 1) +
  ggrepel::geom_text_repel(aes(label = landgebruik, x = jaar + 0.1), data = filter(dat, jaar == rap_jaar) %>% mutate(tijd = 1:6*11-10),
                           hjust = "left",  size = 5, direction = "y", nudge_x = 0.2, xlim = c(NA, rap_jaar + 3)) +

  # geom_smooth(se = FALSE, span = 0.6) +
  # scale_color_brewer(palette = "Dark2", guide = FALSE) +
  scale_colour_manual(values = kleuren_functies_lijnen, guide = FALSE) +
  scale_y_continuous(limits = c(0,NA), expand = expansion(c(0,0.1))) +
  scale_x_continuous(breaks = pretty_breaks(n = 10), limits = c(NA, NA)) +
  labs(title = "Gemiddelde fosfaatconcentratie",
       x = "",
       y = "mg P/l" )  +
  coord_cartesian(clip = "off") +
  theme(plot.margin = margin(5.5, 120, 5.5, 5.5, unit = "pt")) +
  NULL


library(gganimate)

fosfor_plot %>%
  transition_reveal(tijd)

dat %>%
  ggplot(aes(jaar, waarde_gem, group = landgebruik, colour = landgebruik)) +
  geom_line(linewidth = 1) +
  ggrepel::geom_text_repel(aes(label = landgebruik, x = jaar + 0.1), data = filter(dat, jaar == rap_jaar) %>% mutate(tijd = 1:6*11-10),
                           hjust = "left",  size = 5, direction = "y", nudge_x = 0.2, xlim = c(NA, rap_jaar + 3)) +

  # geom_smooth(se = FALSE, span = 0.6) +
  # scale_color_brewer(palette = "Dark2", guide = FALSE) +
  scale_colour_manual(values = kleuren_functies_lijnen, guide = FALSE) +
  scale_y_continuous(limits = c(0,NA), expand = expansion(c(0,0.1))) +
  scale_x_continuous(breaks = pretty_breaks(n = 10), limits = c(NA, NA)) +
  labs(title = "Gemiddelde fosfaatconcentratie",
       x = "",
       y = "mg P/l" )  +
  coord_cartesian(clip = "off") +
  theme(plot.margin = margin(5.5, 120, 5.5, 5.5, unit = "pt")) +
  transition_reveal(tijd)


anim_p <-
  dat %>%
  ggplot(aes(jaar, waarde_gem, group = landgebruik, colour = landgebruik)) +
  geom_line(linewidth = 1) +
  ggrepel::geom_text_repel(aes(label = landgebruik, x = jaar + 0.1), data = filter(dat, jaar == rap_jaar) %>% mutate(tijd = 1:6*11-10),
                           hjust = "left",  size = 5, direction = "y", nudge_x = 0.2, xlim = c(NA, rap_jaar + 3)) +

  # geom_smooth(se = FALSE, span = 0.6) +
  # scale_color_brewer(palette = "Dark2", guide = FALSE) +
  scale_colour_manual(values = kleuren_functies_lijnen, guide = FALSE) +
  scale_y_continuous(limits = c(0,NA), expand = expansion(c(0,0.1))) +
  scale_x_continuous(breaks = pretty_breaks(n = 10), limits = c(NA, NA)) +
  labs(title = "Gemiddelde fosfaatconcentratie",
       x = "",
       y = "mg P/l" )  +
  coord_cartesian(clip = "off") +
  theme(plot.margin = margin(5.5, 120, 5.5, 5.5, unit = "pt")) +
  transition_reveal(tijd)

(anim_p +
  theme(text = element_text(size = 16))) %>%
  animate(duration = 10, nframes = 100, height = 480, width = 720, ref_frame = -1,
          renderer = gifski_renderer(loop = FALSE))



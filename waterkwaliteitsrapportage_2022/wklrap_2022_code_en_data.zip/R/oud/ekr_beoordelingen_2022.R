library(tidyverse)
library(readxl)
library(openxlsx)

data <- read_excel("data/krw_toetsingen_2009_2021.xlsx")

old <- read_excel("data/waterlichamen_ekrs_en_doelen_2021.xlsx")


data %>%
  pivot_longer(cols = starts_with("20"), names_to = "jaar", values_to = "ekr", values_drop_na = TRUE) %>%
  group_by(type, Rapportagepunt, Nr, Naam, gemiddeld_planperiode, Watertype) %>%
  slice_max(order_by = jaar, n = 3) %>%
  summarise(ekr_2022 = mean(ekr)) %>%
  ungroup() %>%
  select(type, Rapportagepunt, OWMIDENT = Nr, OWMNAAM = Naam, Watertype, ekr_2022) %>%
  left_join(old, by = c("type", "OWMIDENT"), suffix = c("", ".y")) %>%
  select(-contains(".y")) %>%
  openxlsx::write.xlsx("data/waterlichamen_ekrs_en_doelen_2022.xlsx")

  # mutate(gemiddeld_planperiode - gem_ekr) %>% View()

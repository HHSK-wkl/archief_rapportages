sno_per_mp <-
  toetsing %>%
  # filter(aantal > aantal_det) %>% # dit filter verwijderd meetpunten waar nooit GBM worden gevonden
  filter(jaar == rap_jaar) %>%
  group_by(jaar, mp) %>%
  summarise(sno = sum(hoogste_overschrijding)) %>%
  left_join(meetpunten)

grafiek_SNO <-
  sno_per_mp %>%
  ggplot(aes(x = sno,
             y = fct_reorder(mp, sno),
             fill = fct_reorder(`landgebruik 2015`, sno, .desc = TRUE, .fun = max),
             text = glue("<b>Overschrijdingsfactor:</b> {round(sno, digits = 0)}<br><b>Meetpunt: {mp}</b>"))) +
  geom_col(colour = "grey60") +
  # scale_x_log10(breaks = scales::breaks_log(7), limits = c(0.42, NA),
  #               labels = scales::label_number(big.mark = "", digits = 1, drop0trailing = TRUE)) +
  scale_y_discrete(labels = NULL) +
  scale_fill_manual(values = c(Akkerbouw       = RColorBrewer::brewer.pal(12, "Set3")[6], # akkerbouw
                               Boezem          = RColorBrewer::brewer.pal(12, "Set3")[5],# boezem
                               "Afvoer/gemaal" = RColorBrewer::brewer.pal(12, "Set3")[9], #afvoer
                               Glastuinbouw    = RColorBrewer::brewer.pal(12, "Set3")[1],
                               Gras            = RColorBrewer::brewer.pal(12, "Set3")[7],
                               Stedelijk       = RColorBrewer::brewer.pal(12, "Set3")[4])) +
  labs(title = "TITEL",
       x = "Gesommeerde normoverschrijding",
       y = "") +
  guides(fill = guide_legend(title = "") ) +
  hhskthema_bar +
  theme(axis.line.y = element_blank(),
        axis.ticks.y = element_blank(),
        axis.line.x = element_line(colour = hhskblauw),
        axis.ticks.x = element_line(colour = hhskblauw),
        # plot.margin = margin(5.5, 15, 5.5, 5.5),
        plot.title = element_markdown(hjust = 0),
        panel.grid.major.x = element_line()
  ) +
  coord_cartesian(xlim = c(0, 250), expand = c(0, 0)) +
    geom_text(aes(label = glue("{round(sno)} !")), colour = "red", hjust = 0, x = 235, fontface = "bold", data = filter(sno_per_mp, sno > 250) )

grafiek_SNO %>%
  plotly::ggplotly(tooltip = "text") %>%
  plotly::config(displayModeBar = FALSE) %>%
  plotly::layout(dragmode = FALSE,
                 title = list(x = "0"),
                 hoverlabel = list(align = "left"))

# grafiek_data %>% ggplot(aes(factor(jaar), waarde_gem)) +
#   geom_col() +
#   geom_col(data = grafiek_data_rapjaar, fill = hhskblauw) +
#   facet_grid(landgebruik~parnaamlang, scales = "free", switch = "y")+
#   coord_flip()

data_test <- grafiek_data %>%
  dplyr::filter(parnr == 3) %>%
  arrange(parnr, landgebruik, desc(waarde_gem)) %>%
  mutate(order = row_number(),
         fill_group = ifelse(jaar == rap_jaar, "2019", "Andere jaren"),
         landgebruik = factor(landgebruik, levels = landgebruik_volgorde, ordered = TRUE))

my_plot <- data_test %>%
  ggplot(aes(order, waarde_gem, fill = fill_group, text = tekst)) +
  geom_col() +
  facet_wrap(~landgebruik, ncol = 1, scales = "free_y") +
  scale_x_continuous(breaks = data_test$order,
                     labels = data_test$jaar) +
  scale_y_continuous(limits = c(0,NA), expand = c(0,0)) +

  coord_flip() +
  hhskthema_bar +
  labs(x = "") +
  scale_fill_manual(values = c(hhskblauw, "grey60"), labels = c(rap_jaar, "Andere jaren")) +
  theme(strip.background = element_rect(fill = colorspace::lighten(hhskblauw, amount = 0.9), colour = NA))

ggplotly(my_plot, tooltip = c("text"))



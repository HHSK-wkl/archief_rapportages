toetsing %>%
  filter(normoverschrijding) %>%

  group_by(jaar, mp) %>%
  summarise(sno = sum(hoogste_overschrijding), aantal = sum(normoverschrijding)) %>%
  filter(jaar == 2020) %>%
  ggplot(aes(sno, mp, fill = sno)) + geom_col() + scale_fill_distiller(palette = "Reds") + scale_x_log10()

toetsing %>%
  filter(jaar == 2020) %>%
  filter(normoverschrijding) %>%
  ggplot(aes(mp, naam, size = log(hoogste_overschrijding))) + geom_point()

#' door de detectiegrenswaarde op 0 te zetten wordt alleen uitgegaan van werkelijk gemeten waarden.
#' Het optellen van alle factoren, ook die kleiner dan 1 zijn, geeft dan geen overdrijving van de waarden

toetsing2 <- data_gbm %>% HHSKwkl::toetsing_gbm(normen, factor_detectiegrens = 0) %>%
  filter(aantal > 1)

toetsing2 %>%
  filter(aantal > aantal_det) %>%
  filter( jaar == 2020) %>%
  group_by(jaar, mp) %>%
  summarise(sno = sum(hoogste_overschrijding)) %>%
  ggplot(aes(sno, fct_reorder(mp, sno))) + geom_col() + scale_x_log10()

toetsing0 %>%
  filter(aantal > aantal_det) %>% # dit filter verwijderd meetpunten waar nooit GBM worden gevonden
  filter( jaar == 2020) %>%
  group_by(jaar, mp) %>%
  summarise(sno = sum(hoogste_overschrijding)) %>%
  left_join(meetpunten) %>%
  # filter(!is.na(`landgebruik 2015`)) %>%
  ggplot(aes(sno, fct_reorder(mp, sno), fill = fct_reorder(`landgebruik 2015`, sno, .desc = TRUE, .fun = max), text = round(sno))) +
  geom_col(colour = "grey60") +
  # scale_x_log10(breaks = scales::breaks_log(7)) +
  guides(fill = guide_legend(title = "") ) +
  scale_y_discrete(labels = NULL) +
  scale_fill_manual(values = c(Akkerbouw       = RColorBrewer::brewer.pal(12, "Set3")[6], # akkerbouw
                               Boezem          = RColorBrewer::brewer.pal(12, "Set3")[5],# boezem
                               "Afvoer/gemaal" = RColorBrewer::brewer.pal(12, "Set3")[9], #afvoer
                               Glastuinbouw    = RColorBrewer::brewer.pal(12, "Set3")[1],
                               Gras            = RColorBrewer::brewer.pal(12, "Set3")[7],
                               Stedelijk       = RColorBrewer::brewer.pal(12, "Set3")[4])) +
  hhskthema() +
  coord_cartesian(xlim = c(0.3, 150))

p1 %>% ggplotly(tooltip = "text")

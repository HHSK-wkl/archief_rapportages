pdfs <- list.files("pdfs", full.names = TRUE)

pdftools::pdf_combine(pdfs, output = "rapportage_waterkwaliteit_2022_HHSK.pdf")

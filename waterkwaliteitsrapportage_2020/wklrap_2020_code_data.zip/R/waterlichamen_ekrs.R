library(tidyverse)
library(sf)
library(HHSKwkl)
library(colorspace)

# waterlichamen <- st_read("../../../Gegevensbeheer/DAWACO/Inrichting DAWACO/Meetpunten/_Genereren_meetpuntkenmerken/data/waterlichamen_2016_2021//Waterdelen_NL39.shp") %>%
#   group_by(OWMIDENT, OWMNAAM) %>%
#   summarise(n = n()) %>%
#   ungroup() %>%
#   select(-n)
#
# st_write(waterlichamen, "data/waterlichamen.gpkg")

waterlichamen <- st_read("data/waterlichamen.gpkg")
ws_grens <- st_read("data/ws_grens.gpkg")

waterlichamen %>%
  ggplot(aes(text = OWMNAAM)) + ggspatial::annotation_map_tile(type = "cartolight") + geom_sf(aes(colour = OWMIDENT, fill = OWMIDENT), size = 1.2) +
  guides(fill = "none", colour = "none")

# waterlichamen %>% st_drop_geometry() %>% openxlsx::write.xlsx("data/waterlichamen.xlsx")

temp <- readxl::read_excel("data/oud/waterlichamen.xlsx") %>%
  pivot_longer(cols = c(Algen, Waterplanten, Macrofauna, Vis), names_to = "type", values_to = "ekr_2020")

p2 <- waterlichamen %>% left_join(temp) %>%
  mutate(kleur = cut(ekr_2020, c(0,0.2,0.4,0.6,1))) %>%
  filter(!is.na(kleur)) %>%
  ggplot() +
  geom_sf(colour = NA, fill = "grey90", data = ws_grens) +
  geom_sf(aes(fill = kleur, colour = kleur, text = OWMNAAM)) +
  scale_fill_manual(values = c("red", "orange", "yellow", "green")) +
  scale_colour_manual(values = c("red", "orange", "yellow", "green")) +
  facet_wrap(~type) +
  hhskthema_kaart()


temp2 <- readxl::read_excel("data/waterlichamen.xlsx") %>% rowwise() %>% mutate(oordeel = min(Algen, Waterplanten, Macrofauna, Vis, na.rm = TRUE))

p1 <- waterlichamen %>% left_join(temp2) %>%
  mutate(kleur = cut(oordeel, c(0,0.2,0.4,0.6,1))) %>%
  filter(!is.na(kleur)) %>%
  ggplot(aes(fill = kleur, colour = kleur)) + geom_sf() +
  scale_fill_manual(values = c("red", "orange", "yellow", "green")) +
  scale_colour_manual(values = c("red", "orange", "yellow", "green"))

library(patchwork)

p1 / p2

ggplotly(p2, tooltip = "text")


doelen <- readxl::read_excel("data/oud/KRW-doelen 2022-2027.xlsx") %>%
  pivot_longer(cols = c(Algen, Waterplanten, Macrofauna, Vis), names_to = "type", values_to = "doelen")


temp %>% left_join(doelen, by = c(OWMNAAM = "Waterlichaam", "type", "Watertype")) %>%
  openxlsx::write.xlsx("data/waterlichamen_ekrs_en_doelen.xlsx")

krw_data <- readxl::read_excel("data/waterlichamen_ekrs_en_doelen.xlsx") %>%
  mutate(type = fct_relevel(type, c("Algen", "Waterplanten", "Macrofauna", "Vis")),
         groep = fct_relevel(groep, "Boezem", "Plassen", "Sloten", "Kanalen Krimpenerwaard", "Kanalen Schieland"))

pdf("temp/krw_oordeel_kaart_kleuren_klassiek.pdf", width = 9, height = 6)
waterlichamen %>% left_join(krw_data) %>%
  mutate(fractie = ekr_2020 / doelen,
         fractie = if_else(fractie > 1, 1, fractie)) %>%
  mutate(kleur = cut(fractie, c(0,0.3333,0.6666,0.99999,100))) %>%
  filter(!is.na(kleur)) %>%
  ggplot() +
  geom_sf(colour = NA, fill = "grey90", data = ws_grens) +
  geom_sf(aes(fill = kleur, colour = kleur, text = OWMNAAM)) +
  scale_fill_manual(values = c("red", "orange", "yellow", "green")) +
  scale_colour_manual(values = c("red", "orange", "yellow", "green")) +
  facet_wrap(~type) +
  hhskthema_kaart()
dev.off()

pdf("temp/krw_oordeel_kaart_kleuren_doelbereik.pdf", width = 9, height = 6)
waterlichamen %>% left_join(krw_data) %>%
  mutate(fractie = ekr_2020 / doelen,
         fractie = if_else(fractie > 1, 1, fractie),
         doelgat = 1 - fractie) %>%
  mutate(kleur = cut(fractie, c(0,0.3333,0.6666,0.99999,100))) %>%
  filter(!is.na(kleur)) %>%
  ggplot() +
  geom_sf(colour = NA, fill = "grey90", data = ws_grens) +
  geom_sf(aes(fill =doelgat, colour = doelgat, text = OWMNAAM)) +
  scale_fill_distiller(palette = "OrRd", direction = 1) +
  scale_color_distiller(palette = "OrRd", direction = 1) +
  # scale_fill_manual(values = c("red", "orange", "yellow", "green")) +
  # scale_colour_manual(values = c("red", "orange", "yellow", "green")) +
  facet_wrap(~type) +
  hhskthema_kaart()
dev.off()

krw_data %>%
  mutate(fractie = ekr_2020 / doelen,
         fractie = if_else(fractie > 1, 1, fractie)) %>%
  ggplot(aes(fractie, OWMNAAM)) + geom_col() + facet_grid(cols = vars(type))


pdf("temp/krw_doelgat_groep.pdf", width = 10, height = 8)
krw_data %>%
  mutate(fractie = ekr_2020 / doelen,
         fractie = if_else(fractie > 1, 1, fractie)) %>%
  mutate(doelgat = 1 - fractie) %>%
  rename(doelbereik = fractie) %>%
  pivot_longer(cols = c(doelbereik, doelgat), names_to = "dummy", values_to = "fractie2") %>%
  ggplot(aes(fractie2, fct_reorder(OWMNAAM, OWMIDENT, .fun = first, .desc = TRUE), fill = fct_rev(dummy))) +
  geom_col() +
  facet_grid(cols = vars(type), rows = vars(groep), scales = "free_y", space = "free_y", switch = "y") +
  scale_fill_manual(values = c(doelbereik = hex(HLS(202.5, 0.60, 1)), doelgat = hex(HLS(25, 0.60, 1)))) +
  scale_x_continuous(limits = c(0,1.0), expand = c(0, 0), labels = function(x) scales::percent(x, accuracy = 1)) +
  hhskthema() + theme(panel.spacing = unit(1.5, "lines"),
                      strip.placement = "outside")
dev.off()


krw_data %>%
  mutate(fractie = ekr_2020 / doelen,
         fractie = if_else(fractie > 1, 1, fractie)) %>%
  group_by(OWMNAAM) %>%
  summarise(fractie = mean(fractie)) %>%
  ggplot(aes(fractie, OWMNAAM)) + geom_col()

krw_data %>%
  mutate(fractie = ekr_2020 / doelen,
         fractie = if_else(fractie > 1, 1, fractie)) %>%
  ggplot(aes(type, fractie)) + geom_jitter(colour = hhskblauw, width = 0.15) + hhskthema() +
  scale_y_continuous(limits = c(0,1.05), expand = c(0, 0), labels = function(x) scales::percent(x, accuracy = 1))

hex(HLS(202.5, 0.38, 1))


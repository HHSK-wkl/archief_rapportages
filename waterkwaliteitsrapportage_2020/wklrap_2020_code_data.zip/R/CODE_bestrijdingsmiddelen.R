source("R/CODE_index_setup.R")

## ---- gewasbeschermingsmiddelen ----

data_gbm <- fys_chem %>%
  filter(parnr > 999, parnr < 2000, jaar <= rap_jaar, jaar > 2008) %>%
  group_by(mp, jaar, parnr) %>%
  filter(n() > 1) %>% # verwijder alle meetlocaties waar maar 1 keer is gemeten
  ungroup()

transpermethrin <- tibble(parnr = 1324, naam = "trans-permethrin", wns_code = NA_character_,
                        norm_JGM = NA_real_, norm_MAX = NA_real_, norm_P90 = 0.0002, min_norm = 0.0002)

normen <- HHSKwkl::import_normen_rivm(parameterdf = parameters) %>%
  bind_rows(transpermethrin)

toetsing <- data_gbm %>% HHSKwkl::toetsing_gbm(normen, factor_detectiegrens = 0.5) %>%
  filter(aantal > 1) # screeningswaarden wegfilteren; op 1 waarde is geen toetsing mogelijk


## ---- create-GBM-plots ----

# NO-CHUNK ----gewasbeschermingsmiddelen-aantal-stoffen-grafiek ----

aantal_stoffen <-
  toetsing %>%
  filter(aantal > aantal_det) %>%
  group_by(jaar, parnr) %>%
  summarise(max_factor = max(hoogste_overschrijding)) %>%
  ungroup() %>%
  mutate(categorie = ifelse(max_factor > 1, "Normoverschrijdend", "Aangetroffen")) %>%
  group_by(jaar, categorie) %>%
  summarise(aantal = n()) %>%
  group_by(jaar) %>%
  mutate(totaal = sum(aantal)) %>%
  ungroup() %>%
  mutate(tekst = case_when(
    categorie == "Aangetroffen" ~ glue("{totaal} verschillende gewasbeschermingsmiddelen aangetroffen"),
    categorie == "Normoverschrijdend" ~ glue("{aantal} normoverschrijdende gewasbeschermingsmiddelen"),
  )) %>%
  mutate(cat_fill = paste0(categorie, ifelse(jaar == rap_jaar, "", "_andere_jaren")))

plot_aantal_stoffen <-
  aantal_stoffen %>%
  ggplot(aes(as.character(jaar), aantal, fill = cat_fill, text = tekst)) +
  geom_col(width = 0.8, colour = "grey60", size = 0.2) +
  scale_fill_manual(values = c(Aangetroffen = blauw_m, Normoverschrijdend = oranje_m,
                               Aangetroffen_andere_jaren = blauw_l, Normoverschrijdend_andere_jaren = oranje_l),
                    breaks = c("Aangetroffen", "Normoverschrijdend")) +
  scale_y_continuous(limits = c(0, 95), expand = c(0,0)) +
  labs(title = "Hoeveel verschillende stoffen worden er aangetroffen?",
       y = "Aantal stoffen",
       x = "") +
  guides(fill = guide_legend(title = NULL)) +
  thema_vert_bar +
  theme(axis.line.x = element_line(colour = "grey60"))


plotly_aantal_stoffen <- ggplotly(plot_aantal_stoffen, tooltip = "text") %>%
  plotly::config(displayModeBar = FALSE) %>%
  plotly::layout(dragmode = FALSE,
                 title = list(x = "0"),
                 legend = list(orientation= "h", yanchor = "top"))

# LET OP legenda wordt gewijzigd obv positie
if (plotly_aantal_stoffen$x$data[[2]]$legendgroup == "Aangetroffen_andere_jaren") plotly_aantal_stoffen$x$data[[2]]$showlegend <- FALSE
if (plotly_aantal_stoffen$x$data[[4]]$legendgroup == "Normoverschrijdend_andere_jaren") plotly_aantal_stoffen$x$data[[4]]$showlegend <- FALSE


# NO-CHUNK ---- gewasbeschermingsmiddelen-gem-stoffen-per-monster-grafiek ----

stoffen_per_monster <-
  data_gbm %>%
  filter(is.na(detectiegrens)) %>%
  left_join(select(normen, parnr, min_norm)) %>%
  mutate(categorie = case_when(
    is.na(min_norm)    ~ "Onder de norm",
    waarde > min_norm  ~ "Boven de norm",
    waarde <= min_norm ~"Onder de norm")) %>%
  group_by(mp, jaar, datum, categorie) %>%
  summarise(aantal = n()) %>%
  group_by(jaar, categorie) %>%
  summarise(aantal_per_cat = round(mean(aantal, na.rm = TRUE), digits = 1)) %>%
  mutate(cat_fill = paste0(categorie, ifelse(jaar == rap_jaar, "", "_andere_jaren"))) %>%
  group_by(jaar) %>%
  mutate(aantal_tot = sum(aantal_per_cat),
         tekst = case_when(
           categorie == "Onder de norm" ~ glue("Gemiddeld <b>{aantal_tot}</b> verschillende stoffen aanwezig"),
           categorie == "Boven de norm" ~ glue("Gemiddeld <b>{aantal_per_cat}</b> verschillende stoffen boven normwaarde")
         ))

plot_per_monster <-
  stoffen_per_monster %>%
  ggplot(aes(factor(jaar), aantal_per_cat, fill = fct_rev(cat_fill), text = tekst)) +
  geom_col(width = 0.8, colour = "grey60", size = 0.2) +
  scale_fill_manual(values = c("Onder de norm" = blauw_m, "Boven de norm" = oranje_m,
                               "Onder de norm_andere_jaren" = blauw_l, "Boven de norm_andere_jaren" = oranje_l),

                    breaks = c("Onder de norm" , "Boven de norm"),
                    position = "left") +
  scale_y_continuous(expand = c(0, 0)) +
  labs(title = "Hoeveel gewasbeschermingsmiddelen zitten er in het water?",
       y = "Aantal stoffen",
       x = "",
       caption = "") +
  guides(fill = guide_legend(title = "")) +
  thema_vert_bar +
  theme(plot.subtitle = element_text(face = "italic")) +
  theme(axis.line.x = element_line(colour = "grey60"))


plotly_per_monster <- ggplotly(plot_per_monster, tooltip = "text") %>%
  plotly::config(displayModeBar = FALSE) %>%
  plotly::layout(dragmode = FALSE,
                 title = list(x = "0"),
                 legend = list(orientation= "h", yanchor = "bottom"))

# LET OP legenda wordt gewijzigd obv positie
if (plotly_per_monster$x$data[[1]]$legendgroup == "Onder de norm_andere_jaren") plotly_per_monster$x$data[[1]]$showlegend <- FALSE
if (plotly_per_monster$x$data[[3]]$legendgroup == "Boven de norm_andere_jaren") plotly_per_monster$x$data[[3]]$showlegend <- FALSE


# NO-CHUNK ---- top10-aangetroffen-gbm ----

meest_aangetroffen_stoffen <-

  data_gbm %>%
  filter(jaar == rap_jaar) %>%
  left_join(normen, by = "parnr") %>%
  group_by(naam) %>%
  summarise(aantal_gemeten      = n(),
            aantal_aangetroffen = sum(is.na(detectiegrens)),
            aantal_boven_norm   = sum(is.na(detectiegrens) & waarde > min_norm)) %>%
  mutate(naam = str_to_sentence(naam),
         fractie_aangetroffen   = aantal_aangetroffen / aantal_gemeten,
         fractie_boven_norm     = aantal_boven_norm / aantal_gemeten,
         fractie_aangetroffen_ex= fractie_aangetroffen - fractie_boven_norm) %>%
  arrange(desc(aantal_aangetroffen)) %>%

  pivot_longer(cols = c(fractie_boven_norm, fractie_aangetroffen_ex), names_to = "groep", values_to = "waarde") %>%
  mutate(label_tekst = case_when(
    groep == "fractie_aangetroffen_ex" ~ glue("{naam} is in {aantal_aangetroffen} van de {aantal_gemeten} monsters aangetroffen."),
    groep == "fractie_boven_norm" ~ glue("{naam} is in {aantal_boven_norm} van de {aantal_gemeten} monsters boven de normwaarde gemeten."),
    TRUE ~ "ERROR"

  )) %>%
  select(-contains("aantal")) %>%
  top_n(n = 20, wt = fractie_aangetroffen) %>%
  mutate(naam = fct_reorder(naam, fractie_aangetroffen)) %>%
  mutate(groep2 = ifelse(groep == "fractie_boven_norm", "Boven de norm", "Onder de norm"))

subtitel_tekst <- glue("{blauwe_tekst(meest_aangetroffen_stoffen$naam[[1]])} zit in {blauwe_tekst(scales::percent(meest_aangetroffen_stoffen$fractie_aangetroffen[[1]]))} van alle monsters")

plot_top10 <-
  meest_aangetroffen_stoffen %>%
  ggplot(aes(waarde, naam, fill = fct_rev(groep2), text = label_tekst)) +
  geom_col(width = 0.8, colour = "grey60", size = 0.2) +
  scale_fill_manual(values = c("Onder de norm" = blauw_m, "Boven de norm" = oranje_m)) +
  scale_x_continuous(expand = c(0, 0), limits = c(0,1), labels = scales::percent_format(), position = "top") +
  labs(title = "Welke gewasbeschermingsmiddelen worden het vaakst aangetroffen?",
       # subtitle = subtitel_tekst,
       y = "",
       x = "% van alle metingen",
       caption = "") +
  guides(fill = guide_legend(title = "", reverse = TRUE)) +
  thema_hor_bar +
  theme(legend.position = "top",
        panel.grid.major.x = element_line(size = 1),
        plot.subtitle = element_markdown(),
        plot.margin = margin(t = 5.5, r = 15, b = 5.5, l = 5.5))



# NO-CHUNK % van alle toetsingen ---------------------------------------------------

plot_overschr_freq <-
  toetsing %>%
  mutate(landgebruik = f_landgebruik(mp)) %>%
  group_by(jaar, landgebruik) %>%
  summarise(n_toetsingen = n(),
            n_overschrijdingen = sum(normoverschrijding),
            fractie = n_overschrijdingen / n_toetsingen) %>%
  mutate(landgebruik = fct_reorder(landgebruik, fractie, .desc = TRUE)) %>%
  filter(!is.na(landgebruik)) %>%
  ggplot(aes(jaar, fractie)) +
  geom_smooth(se = FALSE, method = "lm", linetype = "dashed", colour = blauw_l) +
  geom_line(colour = blauw, size = 1) +
  geom_point(size = 1, colour = blauw) +
  facet_wrap(~landgebruik, scales = "free", ncol = 2) +
  scale_y_continuous(expand = c(0,0), limits = c(0, 0.05), labels = scales::percent_format(accuracy = 1)) +
  scale_x_continuous(limits = c(2009, rap_jaar), breaks = scales::breaks_pretty()) +
  labs(title = "Hoe vaak wordt de norm overschreden?",
       subtitle = "per type landgebruik",
       x = "",
       y = "% normoverschrijdingen") +
  thema_line_facet +
  theme(panel.spacing = unit(25, "points"))


# NO-CHUNK PLOT SNO -------------------------------------------------------

# het is de vraag of de factoren onder de norm meegewogen moeten worden.

ind_overschr <- toetsing %>%
  filter(aantal > aantal_det) %>% # dit filter verwijderd meetpunten waar nooit GBM worden gevonden
  # filter(normoverschrijding) %>%
  filter(jaar == rap_jaar) %>%
  group_by(mp) %>%
  slice_max(hoogste_overschrijding, n = 5) %>%
  filter(hoogste_overschrijding >= 0.1) %>%
  mutate(tekst_enkel = glue("{str_to_sentence(naam)}: {signif(hoogste_overschrijding, digits = 3)} x de norm")) %>%
  summarise(label_tekst_basis = glue_collapse(tekst_enkel, sep = "<br>"))

sno_per_mp <-
  toetsing %>%
  filter(aantal > aantal_det) %>% # dit filter verwijderd meetpunten waar nooit GBM worden gevonden
  # filter(normoverschrijding) %>%
  filter(jaar == rap_jaar) %>%
  left_join(ind_overschr, by = "mp") %>%
  group_by(jaar, mp) %>%
  left_join(meetpunten) %>%
  mutate(`landgebruik 2015` = ifelse(`landgebruik 2015` == "Afvoer/gemaal", "Poldergemaal", `landgebruik 2015`)) %>%
  summarise(sno = sum(hoogste_overschrijding),
            sno_rond = signif(sno, digits = 3),
            label_tekst = glue("<b>Meetpunt {first(`landgebruik 2015`)}:</b> {first(mp)}<br><b>Opgetelde overschrijding:</b> {sno_rond} x<br><br><b>Top 5</b><br>{first(label_tekst_basis)}")) %>%
  left_join(meetpunten)


grafiek_SNO <-
  sno_per_mp %>%
  mutate(`landgebruik 2015` = ifelse(`landgebruik 2015` == "Afvoer/gemaal", "Poldergemaal", `landgebruik 2015`)) %>%
  ggplot(aes(x = fct_reorder(mp, sno, .desc = TRUE),
             y = sno,
             fill = fct_reorder(`landgebruik 2015`, sno, .desc = TRUE, .fun = max),
             text = label_tekst)) +
  geom_col(colour = "grey60") +
  scale_x_discrete(labels = NULL) +
  scale_y_log10(breaks = scales::breaks_log(7), #limits = c(0.42, NA),
                labels = scales::label_number(big.mark = "", digits = 1, drop0trailing = TRUE)) +
  scale_fill_manual(values = c(Akkerbouw       = RColorBrewer::brewer.pal(12, "Set3")[6], # akkerbouw
                               Boezem          = RColorBrewer::brewer.pal(12, "Set3")[5],# boezem
                               "Poldergemaal"  = RColorBrewer::brewer.pal(12, "Set3")[9], #afvoer
                               Glastuinbouw    = RColorBrewer::brewer.pal(12, "Set3")[1],
                               Gras            = RColorBrewer::brewer.pal(12, "Set3")[7],
                               Stedelijk       = RColorBrewer::brewer.pal(12, "Set3")[4])) +
  labs(title = "Hoe ernstig zijn de normoverschrijdingen?",
       x = "",
       y = "Opgetelde normoverschrijding (logaritmisch)",
       caption = "Elke staaf vertegenwoordigd één meetpunt") +
  guides(fill = guide_legend(title = "") ) +
  thema_vert_bar +
  theme(axis.line.x = element_blank(),
        axis.ticks.x = element_blank(),
        axis.line.y = element_line(colour = "grey60"),
        axis.ticks.y = element_line(colour = "grey60"),
        # plot.margin = margin(5.5, 15, 5.5, 5.5),
        plot.title = element_markdown(hjust = 0),
        panel.grid.major.y = element_line()
        )

plotly_SNO <-
  grafiek_SNO %>%
  plotly::ggplotly(tooltip = "text") %>%
  plotly::config(displayModeBar = FALSE) %>%
  plotly::layout(dragmode = FALSE,
                 title = list(x = "0"),
                 hoverlabel = list(align = "left"))



# NO-CHUNK Niet toetsbare stoffen -----------------------------------------

tabel_niet_toetsbaar <-
  data_gbm %>%
  anti_join(normen, by = "parnr") %>%
  filter(jaar == 2020, is.na(detectiegrens)) %>%
  mutate(Naam = str_to_sentence(f_parnaam(parnr))) %>%
  count(Naam, name = "Aantal keer aangetroffen", sort = TRUE) %>%
  bind_cols(tibble(`Soort stof` = c("Insecticide", "Fungicide"), Bijzonderheden = c("Giftig voor bijen", "Afbraak product van tolylfluanide"))) %>%
  knitr::kable(caption = "Aangetroffen gewasbeschermingsmiddelen zonder norm")




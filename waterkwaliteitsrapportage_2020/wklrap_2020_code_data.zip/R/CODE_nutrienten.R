# rap_jaar <- 2019
source("R/CODE_index_setup.R")

## ---- nutrienten-1 ----

landgebruik_sel <- c("Glastuinbouw", "Gras", "Stedelijk", "Boezem", "Plassen")
mp_sel <- meetpunten %>%
  filter(meetpunttypering == 1, `landgebruik 2015` %in% landgebruik_sel) %>%
  select(mp, landgebruik = `landgebruik 2015`)

# landgebruik_volgorde <- fys_chem %>%
#   inner_join(mp_sel, by = "mp") %>%
#   filter(jaar == rap_jaar, parnr == 3) %>%
#   group_by(parnr, landgebruik, jaar) %>%
#   summarise(waarde_gem = mean(waarde)) %>%
#   arrange(desc(waarde_gem)) %>%
#   .$landgebruik

grafiek_data <- fys_chem %>%
  filter(jaar >= rap_jaar-9, jaar <= rap_jaar, parnr %in% c(3, 7)) %>%
  inner_join(mp_sel, by = "mp") %>%
  # soms worden in 1 maand meerdere metingen gedaan, die betreffende meetpunten wegen dan zwaarder dan de rest.
  # Daarom is het beter om eerst het maandgemiddelde te nemen om bias te voorkomen.
  add_maand() %>%
  group_by(parnr, landgebruik, jaar, maand) %>%
  summarise(waarde = mean(waarde)) %>%
  group_by(parnr, landgebruik, jaar) %>%
  summarise(waarde_gem = mean(waarde)) %>%
  ungroup() %>%
  left_join(parameters, by = "parnr") %>%
  group_by(parnr, landgebruik) %>%
  mutate(rank = rank(waarde_gem),
         tekst = glue("{landgebruik} {jaar}<br>Gemiddeld {format(waarde_gem, digits = 2)} {eenheid}")) %>%
  ungroup() %>%
  arrange(parnr, landgebruik, desc(waarde_gem)) %>%
  mutate(order = row_number(),
         fill_group = ifelse(jaar == rap_jaar, rap_jaar, "Andere jaren"),
         landgebruik = fct_reorder(landgebruik, waarde_gem, .desc = TRUE))



trends <- grafiek_data %>%
  arrange(parnr, landgebruik, jaar) %>%
  group_by(parnr, landgebruik) %>%
  nest() %>%
  mutate(test = map(data, ~trend::mk.test(.$waarde_gem)),
         `p-waarde` = map_dbl(test, ~round(.$p.value, digits = 3)),
         richting = map_dbl(test, ~sign(.$statistic))) %>%
  ungroup() %>%
  mutate(Trend = case_when(
    `p-waarde` > 0.05 ~ "- geen trend",
    `p-waarde` < 0.05 & richting == -1 ~ '- <span style="color:#0079C2;font-weight:normal;">dalende trend</span>',
    `p-waarde` < 0.05 & richting == 1 ~ '- <span style="color:#C25100; font-weight:normal;">stijgende trend</span>'
  ))

grafiek_data2 <-
  grafiek_data %>%
  left_join(trends, by = c("landgebruik", "parnr")) %>%
  mutate(landgebruik = glue("{landgebruik} {Trend}"))

fosfor_plot <-
  grafiek_data2 %>%
  filter(parnr == 3) %>%
  mutate(landgebruik = fct_reorder(landgebruik, waarde_gem, .desc = TRUE)) %>%
  ggplot(aes(as.factor(jaar), waarde_gem, fill = fill_group, text = tekst)) +
  geom_col(width = 0.8) +
  facet_wrap(~landgebruik, ncol = 2, scales = "free") +
  scale_y_continuous(limits = c(0,1.5), expand = c(0,0)) +
  labs(title = "Gemiddelde fosfaatconcentratie",
       x = "",
       y = "mg P/l") +
  thema_line_facet +
  scale_fill_manual(values = c(hhskblauw, "grey60"), labels = c(rap_jaar, "Andere jaren"), ) +
  theme(legend.position = "none",
        panel.spacing = unit(25, "points"),
        axis.ticks.x = element_blank(),
        strip.text = element_markdown())



stikstof_plot <-
  grafiek_data2 %>%
  filter(parnr == 7) %>%
  mutate(landgebruik = fct_reorder(landgebruik, waarde_gem, .desc = TRUE)) %>%
  ggplot(aes(as.factor(jaar), waarde_gem, fill = fill_group, text = tekst)) +
  geom_col(width = 0.8) +
  facet_wrap(~landgebruik, ncol = 2, scales = "free") +
  scale_y_continuous(limits = c(0,11), expand = c(0,0)) +
  labs(title = "Gemiddelde stikstofconcentratie",
       x = "",
       y = "mg N/l") +
  thema_line_facet +
  scale_fill_manual(values = c(hhskblauw, "grey60"), labels = c(rap_jaar, "Andere jaren"), ) +
  theme(legend.position = "none",
        panel.spacing = unit(25, "points"),
        axis.ticks.x = element_blank(),
        strip.text = element_markdown())




## ---- nutrienten-fosfor ----

ggplotly(fosfor_plot, tooltip = c("text")) %>%
  plotly::config(displayModeBar = FALSE) %>%
  layout_ggplotly_nut(y = -0.038) %>%
  layout(dragmode = FALSE,
         hoverlabel = list(align = "left"))

## ---- nutrienten-fosfor-trend ----

# caption_tekst <- paste("Trends in de gemiddelde fosfaatconcentratie in de periode", rap_jaar-9,"-", rap_jaar)
# trends %>% filter(Stof == "Fosfor") %>% knitr::kable(caption = caption_tekst)

## ---- nutrienten-stikstof ----

ggplotly(stikstof_plot, tooltip = c("text")) %>%
  plotly::config(displayModeBar = FALSE) %>%
  layout_ggplotly_nut(x = -0.038) %>%
  layout(dragmode = FALSE,
         hoverlabel = list(align = "left"))

## ---- nutrienten-stikstof-trend ----

# caption_tekst <- paste("Trends in de gemiddelde stikstofconcentratie in de periode", rap_jaar-9,"-", rap_jaar)
# trends %>% filter(Stof == "Stikstof") %>% knitr::kable(caption = caption_tekst)

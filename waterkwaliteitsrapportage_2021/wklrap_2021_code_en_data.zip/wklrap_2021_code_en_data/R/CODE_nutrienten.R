source("R/CODE_index_setup.R")

## ---- nutrienten-1 ----

landgebruik_sel <- c("Glastuinbouw", "Gras", "Stedelijk", "Boezem", "Plassen")
mp_sel <- meetpunten %>%
  filter(meetpunttypering == 1, `landgebruik 2015` %in% landgebruik_sel) %>%
  select(mp, landgebruik = `landgebruik 2015`)

grafiek_data <- fys_chem %>%
  filter(jaar >= rap_jaar-9, jaar <= rap_jaar, parnr %in% c(3, 7)) %>%
  inner_join(mp_sel, by = "mp") %>%
  # soms worden in 1 maand meerdere metingen gedaan, die betreffende meetpunten wegen dan zwaarder dan de rest.
  # Daarom is het beter om eerst het maandgemiddelde te nemen om bias te voorkomen.
  add_maand() %>%
  group_by(parnr, landgebruik, jaar, maand) %>%
  summarise(waarde = mean(waarde)) %>%
  group_by(parnr, landgebruik, jaar) %>%
  summarise(waarde_gem = mean(waarde)) %>%
  ungroup() %>%
  left_join(parameters, by = "parnr") %>%
  group_by(parnr, landgebruik) %>%
  mutate(rank = rank(waarde_gem),
         tekst = glue("{landgebruik} {jaar}<br>Gemiddeld {format(waarde_gem, digits = 2)} {eenheid}")) %>%
  ungroup() %>%
  arrange(parnr, landgebruik, desc(waarde_gem)) %>%
  mutate(order = row_number(),
         fill_group = ifelse(jaar == rap_jaar, rap_jaar, "Andere jaren"),
         landgebruik = fct_reorder(landgebruik, waarde_gem, .desc = TRUE))

kleuren_functies_nutrienten <-
  c(Akkerbouw       = RColorBrewer::brewer.pal(12, "Set3")[6], # akkerbouw
    Boezem          = RColorBrewer::brewer.pal(12, "Set3")[5],# boezem
    "Poldergemaal"  = RColorBrewer::brewer.pal(12, "Set3")[9], #afvoer
    Glastuinbouw    = RColorBrewer::brewer.pal(12, "Set3")[3],
    Gras            = RColorBrewer::brewer.pal(12, "Set3")[7],
    Stedelijk       = RColorBrewer::brewer.pal(12, "Set3")[4],
    Plassen         = RColorBrewer::brewer.pal(12, "Set3")[1])


nutrienten_plot <-
  grafiek_data %>%
  mutate(par_strip = c("3" = "Fosfaat (mg P/l)", "7" = "Stikstof (mg N/l)")[as.character(parnr)]) %>%
  mutate(landgebruik = fct_reorder(landgebruik, .fun = first, waarde_gem, .desc = FALSE)) %>%
  filter(jaar == rap_jaar) %>%
  ggplot(aes(waarde_gem, landgebruik, fill = landgebruik)) +
  geom_col(colour = "grey60", width = 0.85) +
  facet_wrap(vars(par_strip), scales = "free_x", strip.position = "bottom") +
  scale_x_continuous(limits = c(0,NA), expand = expansion(c(0,0.1))) +
  scale_fill_manual(values = kleuren_functies_nutrienten) +
  labs(title = "Nutriënten",
       subtitle = "gemiddeld per gebied in 2021",
       y = "",
       x = "") +
  thema_hor_bar +
  theme(axis.ticks.y = element_blank(),
        strip.placement = "outside",
        strip.background = ggplot2::element_rect(fill = NA, colour = NA),
        strip.text = ggplot2::element_text(face = "bold", color = "grey50", size = 12)) +
  guides(fill = FALSE) +
  geom_vline(xintercept = 0,color = "grey40", size = 0.5) + # kunstmatige y-aslijn
  NULL


trends <- grafiek_data %>%
  arrange(parnr, landgebruik, jaar) %>%
  group_by(parnr, landgebruik) %>%
  nest() %>%
  mutate(test = map(data, ~trend::mk.test(.$waarde_gem)),
         `p-waarde` = map_dbl(test, ~round(.$p.value, digits = 3)),
         richting = map_dbl(test, ~sign(.$statistic))) %>%
  ungroup() %>%
  mutate(Trend = case_when(
    `p-waarde` > 0.05 ~ "- geen trend",
    `p-waarde` < 0.05 & richting == -1 ~ '- <span style="color:#0079C2;font-weight:normal;">dalende trend</span>',
    `p-waarde` < 0.05 & richting == 1 ~ '- <span style="color:#C25100; font-weight:normal;">stijgende trend</span>'
  ))

grafiek_data2 <-
  grafiek_data %>%
  mutate(kleur = kleuren_functies_nutrienten[as.character(landgebruik)]) %>%
  left_join(trends, by = c("landgebruik", "parnr")) %>%
  mutate(landgebruik = glue("{landgebruik} {Trend}"))

fosfor_plot <-
  grafiek_data2 %>%
  filter(parnr == 3) %>%
  mutate(landgebruik = fct_reorder(landgebruik, waarde_gem, .desc = TRUE)) %>%
  ggplot(aes(as.factor(jaar), waarde_gem, fill = kleur, text = tekst)) +
  geom_col(width = 0.8, colour = "grey60") +
  facet_wrap(~landgebruik, ncol = 2, scales = "free") +
  scale_y_continuous(limits = c(0,NA), expand = expansion(c(0,0.1))) +
  labs(title = "Gemiddelde fosfaatconcentratie",
       x = "",
       y = "mg P/l",
       caption = "N.B. De schaal van de Y-as verschilt per figuur.") +
  thema_line_facet +
  scale_fill_identity() +
  # scale_fill_manual(values = c(hhskblauw, "grey60"), labels = c(rap_jaar, "Andere jaren"), ) +
  theme(legend.position = "none",
        panel.spacing = unit(25, "points"),
        axis.ticks.x = element_blank(),
        strip.text = element_markdown())


stikstof_plot <-
  grafiek_data2 %>%
  filter(parnr == 7) %>%
  mutate(landgebruik = fct_reorder(landgebruik, waarde_gem, .desc = TRUE)) %>%
  ggplot(aes(as.factor(jaar), waarde_gem, fill = kleur, text = tekst)) +
  geom_col(width = 0.8, colour = "grey60") +
  facet_wrap(~landgebruik, ncol = 2, scales = "free") +
  scale_y_continuous(limits = c(0, NA), expand = expansion(c(0,0.1))) +
  labs(title = "Gemiddelde stikstofconcentratie",
       x = "",
       y = "mg N/l",
       caption = "N.B. De schaal van de Y-as verschilt per figuur.") +
  thema_line_facet +
  scale_fill_identity() +
  # scale_fill_manual(values = c(hhskblauw, "grey60"), labels = c(rap_jaar, "Andere jaren"), ) +
  theme(legend.position = "none",
        panel.spacing = unit(25, "points"),
        axis.ticks.x = element_blank(),
        strip.text = element_markdown())


aantal_stoffen <-
  toetsing %>%
  filter(aantal > aantal_det) %>%
  group_by(jaar, parnr) %>%
  summarise(max_factor = max(hoogste_overschrijding)) %>%
  ungroup() %>%
  mutate(categorie = ifelse(max_factor > 1, "Normoverschrijdend", "Aangetroffen")) %>%
  group_by(jaar, categorie) %>%
  summarise(aantal = n()) %>%
  group_by(jaar) %>%
  mutate(totaal = sum(aantal)) %>%
  ungroup() %>%
  mutate(tekst = case_when(
    categorie == "Aangetroffen" ~ glue("{totaal} verschillende gewasbeschermingsmiddelen aangetroffen"),
    categorie == "Normoverschrijdend" ~ glue("{aantal} normoverschrijdende gewasbeschermingsmiddelen"),
  )) %>%
  mutate(cat_fill = paste0(categorie, ifelse(jaar == rap_jaar, "", "_andere_jaren"))) %>%

plot_aantal_stoffen <-
  aantal_stoffen %>%
  ggplot(aes(as.character(jaar), aantal, fill = cat_fill, text = tekst)) +
  geom_col(width = 0.8, colour = "grey60") +
  scale_fill_manual(values = c(Aangetroffen = hhskblauw, Normoverschrijdend = oranje,
                               Aangetroffen_andere_jaren = blauw_l, Normoverschrijdend_andere_jaren = oranje_l),
                    breaks = c("Aangetroffen", "Normoverschrijdend")) +
  scale_y_continuous(limits = c(0, 95), expand = c(0,0)) +
  labs(title = "Aangetroffen en normoverschrijdende stoffen",
       y = "Aantal stoffen",
       x = "") +
  guides(fill = guide_legend(title = NULL)) +
  hhskthema_bar



plotly_aantal_stoffen <- ggplotly(plot_aantal_stoffen, tooltip = "text") %>%
  plotly::config(displayModeBar = FALSE) %>%
  plotly::layout(dragmode = FALSE,
                 title = list(x = "0"))

# LET OP legenda wordt gewijzigd obv positie
if (plotly_aantal_stoffen$x$data[[2]]$legendgroup == "Aangetroffen_andere_jaren") plotly_aantal_stoffen$x$data[[2]]$showlegend <- FALSE
if (plotly_aantal_stoffen$x$data[[4]]$legendgroup == "Normoverschrijdend_andere_jaren") plotly_aantal_stoffen$x$data[[4]]$showlegend <- FALSE


